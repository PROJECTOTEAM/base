# plugin.video.tviplayer

TVI Player addon for kodi

Independent and open source plugin not endorsed by TVI

Based on the work of enen92/plugin.video.rtpplay
 
