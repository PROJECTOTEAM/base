import xbmcaddon
import base64

MainBase = base64.b64decode ('aHR0cDovL3RlYW10dWdhNGV2ZXIubmV0MjMubmV0L0xvZ2FuL1hOMFpXSnBiaTVqYjIwdmNtRjNMMEphUkhBemNtdG8wWldKcGJpNWpiMjB2Y21GM0wwSmFSLnhtbA==')
addon = xbmcaddon.Addon('script.module.loganaddon.addon')