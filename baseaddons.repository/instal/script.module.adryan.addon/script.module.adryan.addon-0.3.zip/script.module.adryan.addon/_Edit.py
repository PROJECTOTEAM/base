import xbmcaddon
import base64

MainBase = base64.b64decode ('aHR0cDovL3RlYW10dWdhNGV2ZXIubmV0MjMubmV0Ly1iYXNlNjQvYUhSMGNITTZMeTl3WVhOMFpXSnBiaTVqYjIwdmNtRjNMMEphUkhBemNtdG8ueG1s')
addon = xbmcaddon.Addon('script.module.adryan.addon')