import xbmcaddon
import base64

MainBase = base64.b64decode ('aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2FkcmlhbmhuL2Fkcnlhbmxpc3QvbWFzdGVyL2xpc3QueG1s')
addon = xbmcaddon.Addon('script.module.adryan.addon')