import xbmcaddon
import base64

MainBase = base64.b64decode ('aHR0cDovL3RlYW10dWdhNGV2ZXIubmV0MjMubmV0L0FtZXJpa2Fuby9WME1qTXVibVYwTDAxbGJuVWxNakJRY21sdVkybHdZV3d0Ylc5a2RXeGxZV1JrYjI1ekxuaHRiQT0ueG1s')
addon = xbmcaddon.Addon('script.module.amerikano.addon')