import xbmcaddon
import base64

MainBase = base64.b64decode ('aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL0FERE9OQkFTRS9hZGRvbnNiYXNlL21hc3Rlci9WME1qTXVibVYwTDAxbGJuVWxNakJRY21sdVkybHdZV3d0Ylc5a2RXeGxZV1JrYjI1ekxuaHRiQSUzRC54bWw=')
addon = xbmcaddon.Addon('script.module.amerikano.addon')