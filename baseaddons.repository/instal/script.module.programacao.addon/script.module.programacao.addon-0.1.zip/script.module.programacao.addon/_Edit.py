import xbmcaddon
import base64

MainBase = base64.b64decode ('aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL0FERE9OQkFTRS9hZGRvbnNiYXNlL21hc3Rlci9wcm9ncmFtYWNhby54bWw=')
addon = xbmcaddon.Addon('script.module.programacao.addon')