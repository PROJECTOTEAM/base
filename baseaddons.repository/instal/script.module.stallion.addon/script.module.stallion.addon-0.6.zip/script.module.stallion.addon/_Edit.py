import xbmcaddon
import base64

MainBase = base64.b64decode ('aHR0cDovL2RtZnBsd2VnLnBlLmh1L2Zlc3ZzcnZlcmdmd2doNXJoPWFkZG9uPXRlaGJlYnRlaGJ5dHloL3N1Yi1tZW51cy9NT0JEUk8ueG1s')
addon = xbmcaddon.Addon('script.module.stallion.addon')