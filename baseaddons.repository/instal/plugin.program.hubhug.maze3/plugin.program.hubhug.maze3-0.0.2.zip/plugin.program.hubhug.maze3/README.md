plugin.program.hubhug.maze3
===========================

HUB-HUG Exit The Maze 3:  Sleeping Monsters
===========================
$  - User

S  - Start

E  - Exit / End

SPACE  - Path

\#  - Wall

L  - Life

K  - Key

D  - Door

R  - Monster0R

0  - Monster00

1  - Monster01

2  - Monster02

3  - Monster03

4  - Monster04

5  - Monster05

6  - Monster06

7  - Monster07

8  - Monster08

9  - Monster09

Aa Pp Oo Qq Uu Jj  - Portals

s  - Portal to Start Lcation

===========================

Monster Battle Wins/Losses are not currently setup.

When Life hits 0, you loose and you exit from the game automatically.
When you hit the EXIT / END, the game will automatically start another level.

You can only pass a DOOR when you have 1 or more key(s).  A key is used up every time you use one to pass through a door.  What can I say, they break EASILY!

Please note that there are Sound FX(s) in this game.  So adjust volume settings accordingly in XBMC and/or your OS.



Addon Settings
===========================

Player Avatar  - Select the graphic you'll play as.

Select Map  - There is an option in Addon Settings to let you manually browse/select a map.

Show map  - Show Text type Map.

/\

Show location on the map  - Update Text type map as you move.

Show items  - Display items and monsters even when not next to them.


Functionality
===========================

Exit by Exit-Button, Backspace, or Escape.

Selectable Character Avatar in settings.

Text-based Minimap.

Stats for Level, Life and Keys.

OUTSIDE OF GRID padding for visual display.

LINE WRAPPING padding for visual display.

Extremely custamizable Code and Options for easier porting to make additional games.

Items: Key (unlocks a Door), Life (allows you to surve a monster battle).

Monsters: R,0,1,2,3,4,5,6,7,8,9.

Teleport Locations.

Ability to carry over Life and Keys from one Level to the next.




Not Functional Yet
===========================

Multiple outcomes for Monster Battles .

Final Victory.




===========================
