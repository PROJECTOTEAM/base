import xbmcaddon
import base64

MainBase = base64.b64decode ('aHR0cDovL3RlYW10dWdhNGV2ZXIubmV0MjMubmV0Ly1iYXNlNjQvYUhSMGNEb3ZMM1JsWVcxMGRXZGhOR1YyWlhJdWJtVjBNak11Ym1WMEwwMWxiblVsTWpCUWNtbHVZMmx3WVd3dGJXOWtkV3hsWVdSa2IyNXpMbmh0YkE9PS54bWw=')
addon = xbmcaddon.Addon('script.module.schism.addon')