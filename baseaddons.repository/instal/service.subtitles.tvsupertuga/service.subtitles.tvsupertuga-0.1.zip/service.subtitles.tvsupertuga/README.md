OpenSubtitles.org KODI add-on
=============================
Search and download subtitles for movies and TV-Series from OpenSubtitles.org. Search in 75 languages, 4.000.000+ subtitles, daily updates.
                            
Changelog

